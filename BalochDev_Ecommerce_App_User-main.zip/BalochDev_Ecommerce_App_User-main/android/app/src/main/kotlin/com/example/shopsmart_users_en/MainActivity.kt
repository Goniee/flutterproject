package com.example.balochdev_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
