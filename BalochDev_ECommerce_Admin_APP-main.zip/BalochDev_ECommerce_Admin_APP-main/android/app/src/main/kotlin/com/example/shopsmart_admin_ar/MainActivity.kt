package com.example.balochdev_shop_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
