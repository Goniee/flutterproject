class CategoryModel {
  final String id, image, name;

  CategoryModel({
    required this.id,
    required this.image,
    required this.name,
  });
}
